﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MVCMontadoraPP.Migrations.MVCMontadoraPP
{
    public partial class MVCMontadoraPP : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
